package com.atguigu.daijia.order.mapper;

import com.atguigu.daijia.model.entity.order.OrderStatusLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrderStatusLogMapper extends BaseMapper<OrderStatusLog> {


}
