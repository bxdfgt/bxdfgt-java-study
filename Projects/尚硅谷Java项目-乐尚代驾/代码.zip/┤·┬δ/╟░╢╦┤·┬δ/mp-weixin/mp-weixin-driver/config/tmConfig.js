"use strict";
const tmConfig = {
  // 在进阶指南中会讲到类型文件的使用。请注意右侧文档栏目。
  // 指定了类型后，在里面输入会有类型提示和校验。
  shareDisable: false
};
exports.tmConfig = tmConfig;
