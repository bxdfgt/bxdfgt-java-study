"use strict";
const QqMapkey = "PYOBZ-Y6ZRZ-HMZXP-ZTMES-TNAQ7-WZFYS";
exports.QqMapkey = QqMapkey;
